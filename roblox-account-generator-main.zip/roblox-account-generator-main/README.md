
# roblox-account-creator

<a href="https://discord.gg/switchuwu"><img src="https://discordapp.com/api/guilds/1241323594567520337/widget.png?style=banner2"></a>

^^ **❗️ want proxies works on roblox and capbypass? just use capbypass proxies! ** ^^

go discord.gg/switchuwu and write !help

price: 2$/gb

![hxbDED](https://github.com/emrovsky/roblox-account-generator/assets/85563550/c8820a7c-e184-42bb-86c0-79276e3daa39)



an roblox account generator for kids,requests based.



❗️you can create a capbypass account and buy an api key from [here](https://capbypass.com/signup?inviteCode=1hneCOA)



## 💻 Preview






https://github.com/emrovsky/roblox-account-generator/assets/85563550/df93cd44-d4b9-408e-9b2c-f48540dfac5e





## 👾 Features
- request based creator
- solves funcaptcha with capsolver api
- set up email
- saves username:password:mail:mailpassword:roblosecurity_cookie, u can access mail on mail.tm
- threading support
- humanized accounts, with bio, avatar, etc.


## 🌟 Stars to Unlock

- ✅ 25 Stars | verify mail
- ✅ 50 Stars | humanize the creator, bio, avatar.





## ✍️ Usage
1. Install requirements with pip install
2. put your proxies in proxy.txt
3. set your capbypass key into settings.json, and make settings
4. run with python main.py

## DONATE
LhKwvuMYwua2bTn7B38W5p3KrVWCgEGUgS my ltc adress


## ⚠️ DISCLAIMER
This github repo is for EDUCATIONAL PURPOSES ONLY. I am NOT under any responsibility if a problem occurs.

